#!/bin/bash
docker stack rm ci
